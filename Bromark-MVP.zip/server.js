const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_ME";
const MONGO = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/bromark";

mongoose.connect(MONGO).catch(e => console.error("MongoDB:", e.message));

const productSchema = new mongoose.Schema({
  productId: {type:String, unique:true}, name:String, category:String, unit:String,
  openingStock:{type:Number,default:0}, purchasePrice:{type:Number,default:0},
  sellingPrice:{type:Number,default:0}, minimumStock:{type:Number,default:0},
  active:{type:Boolean,default:true}
},{timestamps:true});

const txnSchema = new mongoose.Schema({
  transactionId:{type:String,unique:true}, type:String, date:{type:Date,default:Date.now},
  customer:String, vendor:String, product:String, quantity:Number, unit:String,
  rate:Number, discount:{type:Number,default:0}, total:Number, paid:{type:Number,default:0},
  pending:{type:Number,default:0}, paymentMode:String, notes:String,
  syncStatus:{type:String,default:"SYNC_PENDING"}
},{timestamps:true});

const expenseSchema = new mongoose.Schema({
  transactionId:{type:String,unique:true}, date:{type:Date,default:Date.now},
  category:String, description:String, amount:Number, paymentMode:String,
  payee:String, notes:String, syncStatus:{type:String,default:"SYNC_PENDING"}
},{timestamps:true});

const paymentSchema = new mongoose.Schema({
  transactionId:{type:String,unique:true}, type:String, date:{type:Date,default:Date.now},
  party:String, amount:Number, paymentMode:String, reference:String, notes:String,
  syncStatus:{type:String,default:"SYNC_PENDING"}
},{timestamps:true});

const Product = mongoose.model("Product", productSchema);
const Transaction = mongoose.model("Transaction", txnSchema);
const Expense = mongoose.model("Expense", expenseSchema);
const Payment = mongoose.model("Payment", paymentSchema);

function auth(req,res,next){
  const h=req.headers.authorization||"";
  if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Unauthorized"});
  try { req.user=jwt.verify(h.slice(7),JWT_SECRET); next(); }
  catch(e){ return res.status(401).json({error:"Invalid session"}); }
}
function txid(prefix){
  const d=new Date(), s=d.toISOString().slice(0,10).replaceAll("-","");
  return `BROMARK-${prefix}-${s}-${Date.now().toString().slice(-6)}`;
}

app.post("/api/login",(req,res)=>{
  const {email,password}=req.body;
  const goodEmail=(email||"").toLowerCase()===(process.env.ADMIN_EMAIL||"goldensandkonark@gmail.com").toLowerCase();
  const goodPassword=password===(process.env.ADMIN_PASSWORD||"");
  if(!goodEmail || !goodPassword) return res.status(401).json({error:"Invalid login"});
  res.json({token:jwt.sign({email,role:"admin"},JWT_SECRET,{expiresIn:"12h"})});
});

app.get("/api/products",auth,async(req,res)=>res.json(await Product.find().sort({name:1})));
app.post("/api/products",auth,async(req,res)=>{
  try {
    const p=await Product.create({...req.body,productId:req.body.productId||`BROMARK-P-${Date.now()}`});
    res.json(p);
  } catch(e){res.status(400).json({error:e.message});}
});
app.put("/api/products/:id",auth,async(req,res)=>{
  try {res.json(await Product.findByIdAndUpdate(req.params.id,req.body,{new:true}));}
  catch(e){res.status(400).json({error:e.message});}
});

app.get("/api/transactions",auth,async(req,res)=>{
  const q={}; if(req.query.type) q.type=req.query.type;
  res.json(await Transaction.find(q).sort({date:-1}).limit(500));
});
app.post("/api/transactions",auth,async(req,res)=>{
  try {
    const b=req.body, total=Math.max(0,(Number(b.quantity)||0)*(Number(b.rate)||0)-(Number(b.discount)||0));
    const doc=await Transaction.create({...b,transactionId:txid(b.type==="SALE"?"SALE":"PUR"),total,
      paid:Number(b.paid)||0,pending:Math.max(0,total-(Number(b.paid)||0))});
    if(b.product){
      const p=await Product.findOne({$or:[{productId:b.product},{name:b.product}]});
      if(p && b.type==="PURCHASE") p.openingStock += Number(b.quantity)||0;
      if(p && b.type==="SALE") p.openingStock -= Number(b.quantity)||0;
      if(p) await p.save();
    }
    res.json(doc);
  } catch(e){res.status(400).json({error:e.message});}
});

app.get("/api/expenses",auth,async(req,res)=>res.json(await Expense.find().sort({date:-1}).limit(500)));
app.post("/api/expenses",auth,async(req,res)=>{
  try {res.json(await Expense.create({...req.body,transactionId:txid("EXP"),amount:Number(req.body.amount)||0}));}
  catch(e){res.status(400).json({error:e.message});}
});

app.get("/api/payments",auth,async(req,res)=>res.json(await Payment.find().sort({date:-1}).limit(500)));
app.post("/api/payments",auth,async(req,res)=>{
  try {res.json(await Payment.create({...req.body,transactionId:txid(req.body.type==="CUSTOMER"?"CPAY":"VPAY"),amount:Number(req.body.amount)||0}));}
  catch(e){res.status(400).json({error:e.message});}
});

app.get("/api/dashboard",auth,async(req,res)=>{
  const start=new Date(); start.setHours(0,0,0,0);
  const sales=await Transaction.find({type:"SALE",date:{$gte:start}});
  const purchases=await Transaction.find({type:"PURCHASE",date:{$gte:start}});
  const expenses=await Expense.find({date:{$gte:start}});
  const salesTotal=sales.reduce((a,x)=>a+(x.total||0),0);
  const purchaseTotal=purchases.reduce((a,x)=>a+(x.total||0),0);
  const expenseTotal=expenses.reduce((a,x)=>a+(x.amount||0),0);
  res.json({sales:salesTotal,purchases:purchaseTotal,expenses:expenseTotal,grossProfit:salesTotal-purchaseTotal,netProfit:salesTotal-purchaseTotal-expenseTotal});
});

app.get("/api/health",(req,res)=>res.json({ok:true,app:"Bromark",database:mongoose.connection.readyState===1?"CONNECTED":"DISCONNECTED"}));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

app.listen(PORT,()=>console.log(`Bromark running on http://localhost:${PORT}`));
