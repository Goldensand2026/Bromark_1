# BROMARK Business Management MVP

A practical farm/fresh-food management application designed around:
- MongoDB as the primary database
- Google Sheets/Drive as an optional secondary sync/backup layer
- INR and Asia/Kolkata
- Products: Chicks, Chicken, Basa Fish, Other Fish, Prawns, Eggs

## Run

1. Copy `.env.example` to `.env`
2. Set `MONGODB_URI`
3. Set a strong `JWT_SECRET`
4. `npm install`
5. `npm run dev`

The application is intentionally MVP-focused and avoids paid services by default.

## Security

Do not commit `.env`, Google service-account JSON, API keys, or passwords.
The supplied admin password is NOT written into this package. Set it through environment variables and change it before production use.
